var searchData=
[
  ['quality_20of_20service_698',['Quality of service',['../qos.html',1,'']]]
];
